import httpx
import os
import tempfile
from typing import Dict, Any
from pydub import AudioSegment
from app.core.config import settings

# Sửa đúng path nếu máy bạn khác
AudioSegment.converter = r"C:\Users\grill\AppData\Local\Microsoft\WinGet\Links\ffmpeg.exe"
AudioSegment.ffmpeg = r"C:\Users\grill\AppData\Local\Microsoft\WinGet\Links\ffmpeg.exe"
AudioSegment.ffprobe = r"C:\Users\grill\AppData\Local\Microsoft\WinGet\Links\ffprobe.exe"


class STTService:
    def __init__(self):
        self.openai_url = f"{settings.OPENAI_BASE_URL}/audio/transcriptions"
        self.groq_url = f"{settings.GROQ_BASE_URL}/audio/transcriptions"

    def convert_to_wav(self, input_bytes: bytes, input_format: str = "webm") -> str:
        with tempfile.NamedTemporaryFile(delete=False, suffix=f".{input_format}") as temp_input:
            temp_input.write(input_bytes)
            input_path = temp_input.name

        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_output:
            output_path = temp_output.name

        audio = AudioSegment.from_file(input_path, format=input_format)
        audio.export(output_path, format="wav")

        os.remove(input_path)
        return output_path

    async def _call_transcription_api(
        self,
        provider: str,
        wav_path: str,
        language: str = "en"
    ) -> Dict[str, Any]:
        if provider == "openai":
            url = self.openai_url
            api_key = settings.OPENAI_API_KEY
            model = settings.STT_MODEL
        elif provider == "groq":
            url = self.groq_url
            api_key = settings.GROQ_API_KEY
            model = settings.GROQ_STT_MODEL
        else:
            return {
                "success": False,
                "text": None,
                "error": f"Unsupported STT provider: {provider}",
                "provider": provider,
                "status_code": None,
            }

        headers = {
            "Authorization": f"Bearer {api_key}"
        }

        async with httpx.AsyncClient(
            timeout=settings.REQUEST_TIMEOUT,
            follow_redirects=True,
            trust_env=False
        ) as client:
            with open(wav_path, "rb") as f:
                files = {
                    "file": ("audio.wav", f, "audio/wav")
                }
                data = {
                    "model": model,
                    "language": language
                }

                response = await client.post(
                    url,
                    headers=headers,
                    data=data,
                    files=files
                )

        if response.status_code == 200:
            result = response.json()
            return {
                "success": True,
                "text": result.get("text"),
                "error": None,
                "provider": provider,
                "status_code": 200,
            }

        return {
            "success": False,
            "text": None,
            "error": response.text,
            "provider": provider,
            "status_code": response.status_code,
        }

    async def transcribe(
        self,
        audio_data: bytes,
        filename: str = "audio.webm",
        content_type: str = "audio/webm",
        language: str = "en"
    ) -> Dict[str, Any]:
        wav_path = None

        try:
            ext = os.path.splitext(filename)[1].lower()
            input_format = ext.replace(".", "") if ext else "webm"

            wav_path = self.convert_to_wav(audio_data, input_format=input_format)

            primary = settings.STT_PROVIDER.lower()
            fallback = settings.STT_FALLBACK_PROVIDER.lower()

            primary_result = await self._call_transcription_api(
                provider=primary,
                wav_path=wav_path,
                language=language
            )

            if primary_result["success"]:
                return primary_result

            error_text = (primary_result.get("error") or "").lower()
            should_fallback = (
                primary_result.get("status_code") == 429
                or "insufficient_quota" in error_text
                or "quota" in error_text
            )

            if should_fallback and fallback and fallback != primary:
                fallback_result = await self._call_transcription_api(
                    provider=fallback,
                    wav_path=wav_path,
                    language=language
                )

                if fallback_result["success"]:
                    return fallback_result

                return {
                    "success": False,
                    "text": None,
                    "error": (
                        f"Primary STT failed ({primary}): {primary_result['error']} | "
                        f"Fallback STT failed ({fallback}): {fallback_result['error']}"
                    ),
                    "provider": fallback,
                    "status_code": fallback_result.get("status_code"),
                }

            return primary_result

        except Exception as e:
            return {
                "success": False,
                "text": None,
                "error": str(e),
                "provider": settings.STT_PROVIDER,
                "status_code": None,
            }

        finally:
            if wav_path and os.path.exists(wav_path):
                os.remove(wav_path)


stt_service = STTService()